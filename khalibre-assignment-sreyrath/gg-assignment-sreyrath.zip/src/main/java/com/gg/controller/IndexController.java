package com.gg.controller;

import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.gg.dto.Book;

@Controller
@RequestMapping(value="/")
public class IndexController {
	
	@Autowired
	RestTemplate restTemplate;
	
	private int COUNT = 10;
	
	/**
	 * Get all book lists
	 */
	@RequestMapping(method = RequestMethod.GET)
	public String getBookList(Model model) {
		String url = "http://assignment.gae.golgek.mobi/api/v1/items";
		List<LinkedHashMap> books = restTemplate.getForObject(url, List.class, 0, COUNT);
		model.addAttribute("books", books);
		
		model.addAttribute("offset", 0);
		model.addAttribute("count", COUNT);
		return "bookList";
	}
	
	/**
	 * Get book Detail
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public ModelAndView getBook(@PathVariable("id") int id) {
		String url = "http://assignment.gae.golgek.mobi/api/v1/items/{id}";
		Book book = restTemplate.getForObject(url, Book.class, id);
		
		return new ModelAndView("bookDetail", "book", book);
	}
	
	/**
	 * Pagination
	 */
	@RequestMapping( value = "/next/{offset}", method = RequestMethod.GET)
	public String next(Model model, @PathVariable("offset") int offset){
		int newoffset = offset * 10;
		
		String url = "http://assignment.gae.golgek.mobi/api/v1/items?offset={newoffset}&count={count}";
		List<LinkedHashMap> books = restTemplate.getForObject(url, List.class, newoffset, COUNT);
		model.addAttribute("books", books);
		model.addAttribute("offset", offset);
		
		model.addAttribute("count", COUNT);
		
		return "bookList";
	}
	
	@RequestMapping( value = "/prev/{offset}", method = RequestMethod.GET)
	public String prev(Model model,  @PathVariable("offset") int offset){
		
		int newoffset = offset * 10;
		
		model.addAttribute("count", COUNT);
		
		String url = "http://assignment.gae.golgek.mobi/api/v1/items?offset={offset}&count={count}";
		List<LinkedHashMap> books = restTemplate.getForObject(url, List.class, newoffset, COUNT);
		
		model.addAttribute("books", books);
		model.addAttribute("offset", offset);
		
		return "bookList";
	}
	
}
